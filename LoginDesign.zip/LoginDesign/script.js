// JavaScript Document

		function login(){
			var user,pass;
			
			user=document.getElementById('user').value;
			pass=document.getElementById('pass').value;
					if(user == 'shoaib' && pass == '123' ){
						window.location.assign('Main.html')
						}
					else{
						alert("Incorrect Username or Password");
						
						}
			
			
			}